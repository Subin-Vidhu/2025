# READ ME: You need to follow in-lab instructions to use python3 in the Terminal in this environment.
# Otherwise, you will receive an error: 
# /bin/sh: 1: python: not found 
# The "Run" menu options or right-clicking and running the file will not work and will result in error.

# Please also follow instructions at the end of the ungraded lab to "Mark as completed" and receive
# credit. As this is an ungraded lab, you need to mark it as completed to get credit for completion.

import string_utils
sentence = "This is a test sentence to count vowels."
vowel_count = string_utils.count_vowels(sentence)
print("Number of vowels:", vowel_count) 